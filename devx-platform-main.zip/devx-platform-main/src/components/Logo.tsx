export const Logo = () => {
  return <div>
    <img src="/assets/logo-light.svg" alt="devX" className="h-10 " />
  </div>;
};
