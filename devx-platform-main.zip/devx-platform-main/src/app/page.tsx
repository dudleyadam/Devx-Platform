"use client";
import DevSocialFeed from "@/components/LandingPageFeed/DevSocialFeed";

export default function Home() {
  return <DevSocialFeed />;
}
