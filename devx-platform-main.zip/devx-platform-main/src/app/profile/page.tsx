import UserProfileComponent from "@/components/Profile/UserProfileComponent";
import React from "react";

const page = () => {
  return <UserProfileComponent />;
};

export default page;
